const express = require('express');
const bodyParser = require('body-parser');

const leaderRouter = express.Router();
leaderRouter.use(bodyParser.json());

//I am going to chain all end points (get, post,pit and delete) to leaderRouter!

leaderRouter
	.route('/')
	.all((req, res, next) => {
		res.statusCode = 200;
		res.setHeader('Content-Type', 'text/plain');
		next();
	})
	.get((req, res, next) => {
		res.end('Will send all information of the leaders to you!');
	})
	.post((req, res, next) => {
		res.end('Will add the leader information: ' + req.body.name + ' with details: ' + req.body.description);
	})
	.put((req, res, next) => {
		res.statusCode = 403;
		res.end('PUT operation not supported on /leaders');
	})
	.delete((req, res, next) => {
		res.end('Deleting all leaders');
	});

/* The following supports leaderId using express Router. End points have also been linked. 
I am going to chain all points to leaderRouter 
*/

leaderRouter
	.route('/:leaderId')
	.all((req, res, next) => {
		res.statusCode = 200;
		res.setHeader('Content-Type', 'text/plain');
		next();
	})
	.get((req, res, next) => {
		res.end('Will send all information of the leaders with the id ' + req.params.leaderId);
	})
	.post((req, res, next) => {
		res.end('Will add the leader info: ' + req.body.name + ' with details: ' + req.body.description);
	})
	.put((req, res, next) => {
		res.statusCode = 403;
		res.end('PUT operation not supported on /leaders/:leaderId');
	})
	.delete((req, res, next) => {
		res.end('Deleting all leaders' + req.params.leaderId);
	});

module.exports = leaderRouter;
