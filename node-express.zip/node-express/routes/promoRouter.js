const express = require('express');
const bodyParser = require('body-parser');

const promoRouter = express.Router();
promoRouter.use(bodyParser.json());

//The following is the promo router info. I am going to chain end points to the promo router.

promoRouter
	.route('/')
	.all((req, res, next) => {
		res.statusCode = 200;
		res.setHeader('Content-Type', 'text/plain');
		next();
	})
	.get((req, res, next) => {
		res.end('Will send all the promotions to you!');
	})
	.post((req, res, next) => {
		res.end('Will add the dish: ' + req.body.name + ' with details: ' + req.body.description);
	})
	.put((req, res, next) => {
		res.statusCode = 403;
		res.end('PUT operation not supported on /promotions');
	})
	.delete((req, res, next) => {
		res.end('Deleting all promotions');
	});

/* The following supports promoId using express Router. End points have also been linked. 
I am going to chain all points to promoRouter.  
*/

promoRouter
	.route('/:promoId')
	.all((req, res, next) => {
		res.statusCode = 200;
		res.setHeader('Content-Type', 'text/plain');
		next();
	})
	.get((req, res, next) => {
		res.end('Will send all promotions with the id ' + req.params.promoId);
	})
	.post((req, res, next) => {
		res.end('Will add the dish: ' + req.body.name + ' with details: ' + req.body.description);
	})
	.put((req, res, next) => {
		res.statusCode = 403;
		res.end('PUT operation not supported on /promotions/:promoId');
	})
	.delete((req, res, next) => {
		res.end('Deleting all promotions' + req.params.promoId);
	});

module.exports = promoRouter;
